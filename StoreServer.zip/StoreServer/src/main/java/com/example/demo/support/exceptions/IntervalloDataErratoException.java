package com.example.demo.support.exceptions;

public class IntervalloDataErratoException extends Exception{
    public IntervalloDataErratoException() {}
}
