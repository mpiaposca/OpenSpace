package com.example.demo.support;

public class MessaggioRisposta {
    private String message;


    public MessaggioRisposta(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}
