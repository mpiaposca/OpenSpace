package com.example.demo.support.exceptions;

public class QuantitaNonDisponibileException extends Exception {
    public QuantitaNonDisponibileException(){}
}
