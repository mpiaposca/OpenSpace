package com.example.demo.support.exceptions;

public class UtenteNonTrovatoException extends Exception{
    public UtenteNonTrovatoException(){}
}
