package com.example.demo.support.exceptions;

public class ProdottoEsistenteException extends Exception{
    public ProdottoEsistenteException(){}
}
