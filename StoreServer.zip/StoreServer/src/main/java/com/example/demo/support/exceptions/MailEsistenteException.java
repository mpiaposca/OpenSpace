package com.example.demo.support.exceptions;

public class MailEsistenteException extends Exception{
    public MailEsistenteException(){}
}
